# Linguabridge Final Demo Guide

## Run the Project

```bash
npm install
npm run dev
```

Open:

```text
http://localhost:3000
```

## Optional Azure Translator Setup

Copy `.env.example` to `.env` and add your Azure Translator key:

```bash
cp .env.example .env
```

Then edit `.env`:

```text
AZURE_TRANSLATOR_KEY=your_translator_key_here
AZURE_TRANSLATOR_ENDPOINT=https://api.cognitive.microsofttranslator.com
AZURE_TRANSLATOR_REGION=koreacentral
```

Restart:

```bash
npm run dev
```

If Azure credentials are missing or the API fails, the app still works using the fallback mock translation layer.

## Demo Flow

1. Show the Azure-ready dashboard design.
2. Point out the five demo users: Rayhan, Jisu, Alex, Ahmed, and Priya.
3. Switch the receiver preview dropdown to show receiver-specific translations.
4. Send a new message as Alex or Rayhan.
5. Click **View Chat History** to show backend memory storage.
6. Click **Download JSON** to export the chat history.
7. Click **Summarize Conversation** to show the AI-style summary.
8. Explain the final Azure architecture:
   - Azure Translator Text API for production translation.
   - Azure OpenAI or Azure AI Language for summary generation.
   - Azure Cosmos DB for persistent conversation storage.

## Final Files to Submit or Present

- `server.js`
- `public/index.html`
- `public/styles.css`
- `public/app.js`
- `package.json`
- `package-lock.json`
- `README.md`
- `.env.example`
- `FINAL_DEMO_GUIDE.md`
- `Linguabridge_Cloud_Chat_Azure_Ready.pptx`
- `Linguabridge_Final_Project_Ready.zip`
