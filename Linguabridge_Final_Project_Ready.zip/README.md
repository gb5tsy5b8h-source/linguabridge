# Linguabridge Azure-Ready Multilingual Chat

Linguabridge is a university mid-checkpoint demo for a multilingual cloud chat product. Each user writes in their preferred language, and every receiver sees the message translated into their selected language.

## Run Commands

```bash
npm install
npm run dev
```

Open the app at:

```text
http://localhost:3000
```

## Azure Translator Setup

Create a `.env` file in the project root:

```bash
cp .env.example .env
```

Add your Azure Translator credentials:

```text
AZURE_TRANSLATOR_KEY=your_translator_key_here
AZURE_TRANSLATOR_ENDPOINT=https://api.cognitive.microsofttranslator.com
AZURE_TRANSLATOR_REGION=koreacentral
```

Then restart the server:

```bash
npm run dev
```

When these values are present, the backend calls the Azure Translator Text API for message translations. If the API key, endpoint, region, or network request fails, the app keeps working by using the local mock translation fallback.

## Demo Users

- Rayhan = Bangla/Bengali
- Jisu = Korean
- Alex = English
- Ahmed = Arabic
- Priya = Hindi

## What Is Included

- Multi-user multilingual chat
- Language dropdown for each user
- Language badge beside each user
- Original message and translated message display
- Source language and receiver language labels
- In-memory backend chat storage
- View Chat History modal
- Download Chat History as JSON
- Local mock conversation summary
- Demo preset messages in Bangla, Korean, English, Arabic, and Hindi
- Premium Azure-style dark dashboard UI with animations

## Azure-Ready Notes

This checkpoint version now supports Azure Translator Text API integration while keeping local fallbacks so it is beginner friendly and easy to run in class.

- Translation uses Azure Translator Text API when `.env` credentials are configured.
- The mock translation layer in `server.js` remains as a fallback if Azure credentials are missing or the API request fails.
- The summary feature currently uses a local mock summarizer in `server.js`.
- The final production version should use Azure OpenAI or Azure AI Language for summaries.
- Chat history is currently stored in backend memory.
- Persistent production storage can be added by replacing the memory array with Azure Cosmos DB.

## Project Files

```text
package.json
package-lock.json
server.js
public/index.html
public/styles.css
public/app.js
README.md
.env.example
FINAL_DEMO_GUIDE.md
Linguabridge_Cloud_Chat_Azure_Ready.pptx
```

## Beginner-Friendly Architecture

The app uses only built-in Node.js modules for the backend. There are no required npm packages, so `npm install` completes quickly and `npm run dev` starts the server directly.

The backend API routes are:

- `GET /api/bootstrap` loads users, languages, messages, and a starter summary.
- `POST /api/users/language` updates a user's selected language.
- `POST /api/messages` stores a new message and creates translated versions.
- `GET /api/messages` returns stored messages.
- `GET /api/summary` generates the local mock summary.
- `GET /api/history/download` downloads the full chat history as JSON.

## Presentation Tip

For the live demo, use the receiver selector to switch between Jisu, Alex, Ahmed, Rayhan, and Priya. The same conversation will instantly change to each receiver's language, which clearly demonstrates the Linguabridge concept.
