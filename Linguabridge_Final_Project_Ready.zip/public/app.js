const state = {
  users: [],
  languages: [],
  messages: [],
  selectedReceiverId: "jisu",
  summary: null,
  isLoading: false
};

const elements = {
  userList: document.querySelector("#userList"),
  messagesList: document.querySelector("#messagesList"),
  receiverSelect: document.querySelector("#receiverSelect"),
  receiverBadge: document.querySelector("#receiverBadge"),
  senderSelect: document.querySelector("#senderSelect"),
  messageForm: document.querySelector("#messageForm"),
  messageInput: document.querySelector("#messageInput"),
  sendButton: document.querySelector("#sendButton"),
  typingIndicator: document.querySelector("#typingIndicator"),
  totalMessages: document.querySelector("#totalMessages"),
  activeLanguages: document.querySelector("#activeLanguages"),
  storedMessages: document.querySelector("#storedMessages"),
  summaryStatus: document.querySelector("#summaryStatus"),
  summaryButton: document.querySelector("#summaryButton"),
  summaryContent: document.querySelector("#summaryContent"),
  summaryPanel: document.querySelector("#summaryPanel"),
  viewHistoryButton: document.querySelector("#viewHistoryButton"),
  historyModal: document.querySelector("#historyModal"),
  historyJson: document.querySelector("#historyJson"),
  closeHistoryButton: document.querySelector("#closeHistoryButton"),
  pipelineOriginal: document.querySelector("#pipelineOriginal"),
  pipelineTarget: document.querySelector("#pipelineTarget")
};

async function bootstrap() {
  setLoading(true);
  const data = await fetchJson("/api/bootstrap");
  state.users = data.users;
  state.languages = data.languages;
  state.messages = data.messages;
  state.summary = data.summary;
  renderAll();
  setLoading(false);
}

async function fetchJson(url, options) {
  const response = await fetch(url, options);
  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: "Request failed." }));
    throw new Error(error.error || "Request failed.");
  }
  return response.json();
}

function renderAll() {
  renderSelectors();
  renderUsers();
  renderMessages();
  renderStats();
  renderReceiverBadge();
  renderPipeline();
}

function renderSelectors() {
  elements.receiverSelect.innerHTML = state.users
    .map((user) => `<option value="${user.id}" ${user.id === state.selectedReceiverId ? "selected" : ""}>${user.name}</option>`)
    .join("");

  elements.senderSelect.innerHTML = state.users
    .map((user) => `<option value="${user.id}">${user.name} · ${getLanguage(user.language).nativeName}</option>`)
    .join("");
}

function renderUsers() {
  elements.userList.innerHTML = state.users.map((user) => {
    const language = getLanguage(user.language);
    return `
      <article class="user-card">
        <div class="avatar-wrap">
          <div class="status-pulse"></div>
          <div class="avatar">${user.name.slice(0, 1)}</div>
        </div>
        <div class="user-meta">
          <strong>${user.name}</strong>
          <span>${user.role}</span>
          <span class="language-badge">${language.flag} ${language.name}</span>
        </div>
        <label class="language-select-label">
          <span>Language</span>
          <select data-user-language="${user.id}" aria-label="${user.name} language">
            ${state.languages.map((option) => `
              <option value="${option.code}" ${option.code === user.language ? "selected" : ""}>
                ${option.flag} ${option.nativeName}
              </option>
            `).join("")}
          </select>
        </label>
      </article>
    `;
  }).join("");
}

function renderMessages() {
  const receiver = getReceiver();
  const receiverLanguage = getLanguage(receiver.language);

  elements.messagesList.innerHTML = state.messages.map((message) => {
    const senderLanguage = getLanguage(message.senderLanguage);
    const translatedText = message.translatedVersions[receiver.language] || message.originalText;
    const isOwnLanguage = message.senderLanguage === receiver.language;
    const direction = receiverLanguage.direction;

    return `
      <article class="message-card ${isOwnLanguage ? "same-language" : ""}">
        <div class="message-topline">
          <div>
            <strong>${message.senderName}</strong>
            <span>${formatTime(message.timestamp)}</span>
          </div>
          <div class="message-badges">
            <span class="language-badge">${senderLanguage.flag} Source: ${senderLanguage.name}</span>
            <span class="language-badge">${receiverLanguage.flag} Receiver: ${receiverLanguage.name}</span>
          </div>
        </div>
        <div class="message-body">
          <div>
            <span class="field-label">Original message</span>
            <p dir="${senderLanguage.direction}">${escapeHtml(message.originalText)}</p>
          </div>
          <div class="translated-block">
            <span class="field-label">Translated for ${receiver.name}</span>
            <p dir="${direction}">${escapeHtml(translatedText)}</p>
          </div>
        </div>
      </article>
    `;
  }).join("");

  elements.messagesList.scrollTop = elements.messagesList.scrollHeight;
}

function renderStats() {
  const activeLanguages = new Set(state.messages.map((message) => message.senderLanguage));
  elements.totalMessages.textContent = state.messages.length;
  elements.activeLanguages.textContent = activeLanguages.size;
  elements.storedMessages.textContent = state.messages.length;
  elements.summaryStatus.textContent = state.summary ? "Ready" : "Pending";
}

function renderReceiverBadge() {
  const receiver = getReceiver();
  const language = getLanguage(receiver.language);
  elements.receiverBadge.textContent = `${language.flag} ${receiver.name} sees ${language.name}`;
}

function renderPipeline() {
  const latest = state.messages[state.messages.length - 1];
  const receiver = getReceiver();
  if (!latest) return;

  elements.pipelineOriginal.textContent = getLanguage(latest.senderLanguage).nativeName;
  elements.pipelineTarget.textContent = getLanguage(receiver.language).nativeName;
}

function renderSummary(summary) {
  elements.summaryContent.innerHTML = `
    <section class="summary-section">
      <span>Main discussion topic</span>
      <p>${escapeHtml(summary.mainDiscussionTopic)}</p>
    </section>
    <section class="summary-section">
      <span>Key points</span>
      <ul>${summary.keyPoints.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>
    </section>
    <section class="summary-section">
      <span>Decisions made</span>
      <ul>${summary.decisionsMade.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>
    </section>
    <section class="summary-section">
      <span>Action items</span>
      <ul>${summary.actionItems.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>
    </section>
    <section class="summary-section">
      <span>Participants</span>
      <p>${summary.participants.join(", ")}</p>
    </section>
  `;
  elements.summaryPanel.classList.add("summary-visible");
}

function getReceiver() {
  return state.users.find((user) => user.id === state.selectedReceiverId) || state.users[0];
}

function getLanguage(code) {
  return state.languages.find((language) => language.code === code) || state.languages[0] || { code: "en", name: "English", nativeName: "English", flag: "🇺🇸", direction: "ltr" };
}

function formatTime(timestamp) {
  return new Intl.DateTimeFormat("en", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  }).format(new Date(timestamp));
}

function escapeHtml(value) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function setLoading(isLoading) {
  state.isLoading = isLoading;
  elements.sendButton.disabled = isLoading;
  elements.summaryButton.disabled = isLoading;
  elements.typingIndicator.hidden = !isLoading;
}

async function changeUserLanguage(userId, language) {
  setLoading(true);
  const data = await fetchJson("/api/users/language", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId, language })
  });
  state.users = data.users;
  renderAll();
  document.body.classList.add("language-transition");
  window.setTimeout(() => document.body.classList.remove("language-transition"), 450);
  setLoading(false);
}

async function sendMessage(event) {
  event.preventDefault();
  const senderId = elements.senderSelect.value;
  const text = elements.messageInput.value.trim();
  if (!text) return;

  setLoading(true);
  await delay(550);
  const data = await fetchJson("/api/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ senderId, text })
  });
  state.messages = data.messages;
  elements.messageInput.value = "";
  renderAll();
  setLoading(false);
}

async function summarizeConversation() {
  setLoading(true);
  elements.summaryStatus.textContent = "Generating";
  await delay(700);
  const data = await fetchJson("/api/summary");
  state.summary = data.summary;
  renderSummary(data.summary);
  renderStats();
  setLoading(false);
}

function openHistory() {
  elements.historyJson.textContent = JSON.stringify({
    exportedAt: new Date().toISOString(),
    users: state.users,
    languages: state.languages,
    messages: state.messages
  }, null, 2);
  elements.historyModal.showModal();
}

function delay(milliseconds) {
  return new Promise((resolve) => window.setTimeout(resolve, milliseconds));
}

elements.receiverSelect.addEventListener("change", (event) => {
  state.selectedReceiverId = event.target.value;
  renderMessages();
  renderReceiverBadge();
  renderPipeline();
});

elements.userList.addEventListener("change", (event) => {
  const userId = event.target.dataset.userLanguage;
  if (userId) changeUserLanguage(userId, event.target.value).catch(showError);
});

elements.messageForm.addEventListener("submit", (event) => {
  sendMessage(event).catch(showError);
});

elements.summaryButton.addEventListener("click", () => {
  summarizeConversation().catch(showError);
});

elements.viewHistoryButton.addEventListener("click", openHistory);
elements.closeHistoryButton.addEventListener("click", () => elements.historyModal.close());

function showError(error) {
  setLoading(false);
  window.alert(error.message);
}

bootstrap().catch(showError);
